public interface IntToDouble {
	double call(int i);
}
